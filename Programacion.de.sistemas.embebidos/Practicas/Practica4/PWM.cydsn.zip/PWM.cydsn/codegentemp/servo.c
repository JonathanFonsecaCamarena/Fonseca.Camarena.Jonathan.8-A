/*******************************************************************************
* File Name: servo.c
* Version 3.30
*
* Description:
*  The PWM User Module consist of an 8 or 16-bit counter with two 8 or 16-bit
*  comparitors. Each instance of this user module is capable of generating
*  two PWM outputs with the same period. The pulse width is selectable between
*  1 and 255/65535. The period is selectable between 2 and 255/65536 clocks.
*  The compare value output may be configured to be active when the present
*  counter is less than or less than/equal to the compare value.
*  A terminal count output is also provided. It generates a pulse one clock
*  width wide when the counter is equal to zero.
*
* Note:
*
*******************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "servo.h"

/* Error message for removed <resource> through optimization */
#ifdef servo_PWMUDB_genblk1_ctrlreg__REMOVED
    #error PWM_v3_30 detected with a constant 0 for the enable or \
         constant 1 for reset. This will prevent the component from operating.
#endif /* servo_PWMUDB_genblk1_ctrlreg__REMOVED */

uint8 servo_initVar = 0u;


/*******************************************************************************
* Function Name: servo_Start
********************************************************************************
*
* Summary:
*  The start function initializes the pwm with the default values, the
*  enables the counter to begin counting.  It does not enable interrupts,
*  the EnableInt command should be called if interrupt generation is required.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  servo_initVar: Is modified when this function is called for the
*   first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void servo_Start(void) 
{
    /* If not Initialized then initialize all required hardware and software */
    if(servo_initVar == 0u)
    {
        servo_Init();
        servo_initVar = 1u;
    }
    servo_Enable();

}


/*******************************************************************************
* Function Name: servo_Init
********************************************************************************
*
* Summary:
*  Initialize component's parameters to the parameters set by user in the
*  customizer of the component placed onto schematic. Usually called in
*  servo_Start().
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void servo_Init(void) 
{
    #if (servo_UsingFixedFunction || servo_UseControl)
        uint8 ctrl;
    #endif /* (servo_UsingFixedFunction || servo_UseControl) */

    #if(!servo_UsingFixedFunction)
        #if(servo_UseStatus)
            /* Interrupt State Backup for Critical Region*/
            uint8 servo_interruptState;
        #endif /* (servo_UseStatus) */
    #endif /* (!servo_UsingFixedFunction) */

    #if (servo_UsingFixedFunction)
        /* You are allowed to write the compare value (FF only) */
        servo_CONTROL |= servo_CFG0_MODE;
        #if (servo_DeadBand2_4)
            servo_CONTROL |= servo_CFG0_DB;
        #endif /* (servo_DeadBand2_4) */

        ctrl = servo_CONTROL3 & ((uint8 )(~servo_CTRL_CMPMODE1_MASK));
        servo_CONTROL3 = ctrl | servo_DEFAULT_COMPARE1_MODE;

         /* Clear and Set SYNCTC and SYNCCMP bits of RT1 register */
        servo_RT1 &= ((uint8)(~servo_RT1_MASK));
        servo_RT1 |= servo_SYNC;

        /*Enable DSI Sync all all inputs of the PWM*/
        servo_RT1 &= ((uint8)(~servo_SYNCDSI_MASK));
        servo_RT1 |= servo_SYNCDSI_EN;

    #elif (servo_UseControl)
        /* Set the default compare mode defined in the parameter */
        ctrl = servo_CONTROL & ((uint8)(~servo_CTRL_CMPMODE2_MASK)) &
                ((uint8)(~servo_CTRL_CMPMODE1_MASK));
        servo_CONTROL = ctrl | servo_DEFAULT_COMPARE2_MODE |
                                   servo_DEFAULT_COMPARE1_MODE;
    #endif /* (servo_UsingFixedFunction) */

    #if (!servo_UsingFixedFunction)
        #if (servo_Resolution == 8)
            /* Set FIFO 0 to 1 byte register for period*/
            servo_AUX_CONTROLDP0 |= (servo_AUX_CTRL_FIFO0_CLR);
        #else /* (servo_Resolution == 16)*/
            /* Set FIFO 0 to 1 byte register for period */
            servo_AUX_CONTROLDP0 |= (servo_AUX_CTRL_FIFO0_CLR);
            servo_AUX_CONTROLDP1 |= (servo_AUX_CTRL_FIFO0_CLR);
        #endif /* (servo_Resolution == 8) */

        servo_WriteCounter(servo_INIT_PERIOD_VALUE);
    #endif /* (!servo_UsingFixedFunction) */

    servo_WritePeriod(servo_INIT_PERIOD_VALUE);

        #if (servo_UseOneCompareMode)
            servo_WriteCompare(servo_INIT_COMPARE_VALUE1);
        #else
            servo_WriteCompare1(servo_INIT_COMPARE_VALUE1);
            servo_WriteCompare2(servo_INIT_COMPARE_VALUE2);
        #endif /* (servo_UseOneCompareMode) */

        #if (servo_KillModeMinTime)
            servo_WriteKillTime(servo_MinimumKillTime);
        #endif /* (servo_KillModeMinTime) */

        #if (servo_DeadBandUsed)
            servo_WriteDeadTime(servo_INIT_DEAD_TIME);
        #endif /* (servo_DeadBandUsed) */

    #if (servo_UseStatus || servo_UsingFixedFunction)
        servo_SetInterruptMode(servo_INIT_INTERRUPTS_MODE);
    #endif /* (servo_UseStatus || servo_UsingFixedFunction) */

    #if (servo_UsingFixedFunction)
        /* Globally Enable the Fixed Function Block chosen */
        servo_GLOBAL_ENABLE |= servo_BLOCK_EN_MASK;
        /* Set the Interrupt source to come from the status register */
        servo_CONTROL2 |= servo_CTRL2_IRQ_SEL;
    #else
        #if(servo_UseStatus)

            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            servo_interruptState = CyEnterCriticalSection();
            /* Use the interrupt output of the status register for IRQ output */
            servo_STATUS_AUX_CTRL |= servo_STATUS_ACTL_INT_EN_MASK;

             /* Exit Critical Region*/
            CyExitCriticalSection(servo_interruptState);

            /* Clear the FIFO to enable the servo_STATUS_FIFOFULL
                   bit to be set on FIFO full. */
            servo_ClearFIFO();
        #endif /* (servo_UseStatus) */
    #endif /* (servo_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: servo_Enable
********************************************************************************
*
* Summary:
*  Enables the PWM block operation
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  This works only if software enable mode is chosen
*
*******************************************************************************/
void servo_Enable(void) 
{
    /* Globally Enable the Fixed Function Block chosen */
    #if (servo_UsingFixedFunction)
        servo_GLOBAL_ENABLE |= servo_BLOCK_EN_MASK;
        servo_GLOBAL_STBY_ENABLE |= servo_BLOCK_STBY_EN_MASK;
    #endif /* (servo_UsingFixedFunction) */

    /* Enable the PWM from the control register  */
    #if (servo_UseControl || servo_UsingFixedFunction)
        servo_CONTROL |= servo_CTRL_ENABLE;
    #endif /* (servo_UseControl || servo_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: servo_Stop
********************************************************************************
*
* Summary:
*  The stop function halts the PWM, but does not change any modes or disable
*  interrupts.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  If the Enable mode is set to Hardware only then this function
*  has no effect on the operation of the PWM
*
*******************************************************************************/
void servo_Stop(void) 
{
    #if (servo_UseControl || servo_UsingFixedFunction)
        servo_CONTROL &= ((uint8)(~servo_CTRL_ENABLE));
    #endif /* (servo_UseControl || servo_UsingFixedFunction) */

    /* Globally disable the Fixed Function Block chosen */
    #if (servo_UsingFixedFunction)
        servo_GLOBAL_ENABLE &= ((uint8)(~servo_BLOCK_EN_MASK));
        servo_GLOBAL_STBY_ENABLE &= ((uint8)(~servo_BLOCK_STBY_EN_MASK));
    #endif /* (servo_UsingFixedFunction) */
}

#if (servo_UseOneCompareMode)
    #if (servo_CompareMode1SW)


        /*******************************************************************************
        * Function Name: servo_SetCompareMode
        ********************************************************************************
        *
        * Summary:
        *  This function writes the Compare Mode for the pwm output when in Dither mode,
        *  Center Align Mode or One Output Mode.
        *
        * Parameters:
        *  comparemode:  The new compare mode for the PWM output. Use the compare types
        *                defined in the H file as input arguments.
        *
        * Return:
        *  None
        *
        *******************************************************************************/
        void servo_SetCompareMode(uint8 comparemode) 
        {
            #if(servo_UsingFixedFunction)

                #if(0 != servo_CTRL_CMPMODE1_SHIFT)
                    uint8 comparemodemasked = ((uint8)((uint8)comparemode << servo_CTRL_CMPMODE1_SHIFT));
                #else
                    uint8 comparemodemasked = comparemode;
                #endif /* (0 != servo_CTRL_CMPMODE1_SHIFT) */

                servo_CONTROL3 &= ((uint8)(~servo_CTRL_CMPMODE1_MASK)); /*Clear Existing Data */
                servo_CONTROL3 |= comparemodemasked;

            #elif (servo_UseControl)

                #if(0 != servo_CTRL_CMPMODE1_SHIFT)
                    uint8 comparemode1masked = ((uint8)((uint8)comparemode << servo_CTRL_CMPMODE1_SHIFT)) &
                                                servo_CTRL_CMPMODE1_MASK;
                #else
                    uint8 comparemode1masked = comparemode & servo_CTRL_CMPMODE1_MASK;
                #endif /* (0 != servo_CTRL_CMPMODE1_SHIFT) */

                #if(0 != servo_CTRL_CMPMODE2_SHIFT)
                    uint8 comparemode2masked = ((uint8)((uint8)comparemode << servo_CTRL_CMPMODE2_SHIFT)) &
                                               servo_CTRL_CMPMODE2_MASK;
                #else
                    uint8 comparemode2masked = comparemode & servo_CTRL_CMPMODE2_MASK;
                #endif /* (0 != servo_CTRL_CMPMODE2_SHIFT) */

                /*Clear existing mode */
                servo_CONTROL &= ((uint8)(~(servo_CTRL_CMPMODE1_MASK |
                                            servo_CTRL_CMPMODE2_MASK)));
                servo_CONTROL |= (comparemode1masked | comparemode2masked);

            #else
                uint8 temp = comparemode;
            #endif /* (servo_UsingFixedFunction) */
        }
    #endif /* servo_CompareMode1SW */

#else /* UseOneCompareMode */

    #if (servo_CompareMode1SW)


        /*******************************************************************************
        * Function Name: servo_SetCompareMode1
        ********************************************************************************
        *
        * Summary:
        *  This function writes the Compare Mode for the pwm or pwm1 output
        *
        * Parameters:
        *  comparemode:  The new compare mode for the PWM output. Use the compare types
        *                defined in the H file as input arguments.
        *
        * Return:
        *  None
        *
        *******************************************************************************/
        void servo_SetCompareMode1(uint8 comparemode) 
        {
            #if(0 != servo_CTRL_CMPMODE1_SHIFT)
                uint8 comparemodemasked = ((uint8)((uint8)comparemode << servo_CTRL_CMPMODE1_SHIFT)) &
                                           servo_CTRL_CMPMODE1_MASK;
            #else
                uint8 comparemodemasked = comparemode & servo_CTRL_CMPMODE1_MASK;
            #endif /* (0 != servo_CTRL_CMPMODE1_SHIFT) */

            #if (servo_UseControl)
                servo_CONTROL &= ((uint8)(~servo_CTRL_CMPMODE1_MASK)); /*Clear existing mode */
                servo_CONTROL |= comparemodemasked;
            #endif /* (servo_UseControl) */
        }
    #endif /* servo_CompareMode1SW */

#if (servo_CompareMode2SW)


    /*******************************************************************************
    * Function Name: servo_SetCompareMode2
    ********************************************************************************
    *
    * Summary:
    *  This function writes the Compare Mode for the pwm or pwm2 output
    *
    * Parameters:
    *  comparemode:  The new compare mode for the PWM output. Use the compare types
    *                defined in the H file as input arguments.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void servo_SetCompareMode2(uint8 comparemode) 
    {

        #if(0 != servo_CTRL_CMPMODE2_SHIFT)
            uint8 comparemodemasked = ((uint8)((uint8)comparemode << servo_CTRL_CMPMODE2_SHIFT)) &
                                                 servo_CTRL_CMPMODE2_MASK;
        #else
            uint8 comparemodemasked = comparemode & servo_CTRL_CMPMODE2_MASK;
        #endif /* (0 != servo_CTRL_CMPMODE2_SHIFT) */

        #if (servo_UseControl)
            servo_CONTROL &= ((uint8)(~servo_CTRL_CMPMODE2_MASK)); /*Clear existing mode */
            servo_CONTROL |= comparemodemasked;
        #endif /* (servo_UseControl) */
    }
    #endif /*servo_CompareMode2SW */

#endif /* UseOneCompareMode */


#if (!servo_UsingFixedFunction)


    /*******************************************************************************
    * Function Name: servo_WriteCounter
    ********************************************************************************
    *
    * Summary:
    *  Writes a new counter value directly to the counter register. This will be
    *  implemented for that currently running period and only that period. This API
    *  is valid only for UDB implementation and not available for fixed function
    *  PWM implementation.
    *
    * Parameters:
    *  counter:  The period new period counter value.
    *
    * Return:
    *  None
    *
    * Side Effects:
    *  The PWM Period will be reloaded when a counter value will be a zero
    *
    *******************************************************************************/
    void servo_WriteCounter(uint16 counter) \
                                       
    {
        CY_SET_REG16(servo_COUNTER_LSB_PTR, counter);
    }


    /*******************************************************************************
    * Function Name: servo_ReadCounter
    ********************************************************************************
    *
    * Summary:
    *  This function returns the current value of the counter.  It doesn't matter
    *  if the counter is enabled or running.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  The current value of the counter.
    *
    *******************************************************************************/
    uint16 servo_ReadCounter(void) 
    {
        /* Force capture by reading Accumulator */
        /* Must first do a software capture to be able to read the counter */
        /* It is up to the user code to make sure there isn't already captured data in the FIFO */
          (void)CY_GET_REG8(servo_COUNTERCAP_LSB_PTR_8BIT);

        /* Read the data from the FIFO */
        return (CY_GET_REG16(servo_CAPTURE_LSB_PTR));
    }

    #if (servo_UseStatus)


        /*******************************************************************************
        * Function Name: servo_ClearFIFO
        ********************************************************************************
        *
        * Summary:
        *  This function clears all capture data from the capture FIFO
        *
        * Parameters:
        *  None
        *
        * Return:
        *  None
        *
        *******************************************************************************/
        void servo_ClearFIFO(void) 
        {
            while(0u != (servo_ReadStatusRegister() & servo_STATUS_FIFONEMPTY))
            {
                (void)servo_ReadCapture();
            }
        }

    #endif /* servo_UseStatus */

#endif /* !servo_UsingFixedFunction */


/*******************************************************************************
* Function Name: servo_WritePeriod
********************************************************************************
*
* Summary:
*  This function is used to change the period of the counter.  The new period
*  will be loaded the next time terminal count is detected.
*
* Parameters:
*  period:  Period value. May be between 1 and (2^Resolution)-1.  A value of 0
*           will result in the counter remaining at zero.
*
* Return:
*  None
*
*******************************************************************************/
void servo_WritePeriod(uint16 period) 
{
    #if(servo_UsingFixedFunction)
        CY_SET_REG16(servo_PERIOD_LSB_PTR, (uint16)period);
    #else
        CY_SET_REG16(servo_PERIOD_LSB_PTR, period);
    #endif /* (servo_UsingFixedFunction) */
}

#if (servo_UseOneCompareMode)


    /*******************************************************************************
    * Function Name: servo_WriteCompare
    ********************************************************************************
    *
    * Summary:
    *  This funtion is used to change the compare1 value when the PWM is in Dither
    *  mode. The compare output will reflect the new value on the next UDB clock.
    *  The compare output will be driven high when the present counter value is
    *  compared to the compare value based on the compare mode defined in
    *  Dither Mode.
    *
    * Parameters:
    *  compare:  New compare value.
    *
    * Return:
    *  None
    *
    * Side Effects:
    *  This function is only available if the PWM mode parameter is set to
    *  Dither Mode, Center Aligned Mode or One Output Mode
    *
    *******************************************************************************/
    void servo_WriteCompare(uint16 compare) \
                                       
    {
        #if(servo_UsingFixedFunction)
            CY_SET_REG16(servo_COMPARE1_LSB_PTR, (uint16)compare);
        #else
            CY_SET_REG16(servo_COMPARE1_LSB_PTR, compare);
        #endif /* (servo_UsingFixedFunction) */

        #if (servo_PWMMode == servo__B_PWM__DITHER)
            #if(servo_UsingFixedFunction)
                CY_SET_REG16(servo_COMPARE2_LSB_PTR, (uint16)(compare + 1u));
            #else
                CY_SET_REG16(servo_COMPARE2_LSB_PTR, (compare + 1u));
            #endif /* (servo_UsingFixedFunction) */
        #endif /* (servo_PWMMode == servo__B_PWM__DITHER) */
    }


#else


    /*******************************************************************************
    * Function Name: servo_WriteCompare1
    ********************************************************************************
    *
    * Summary:
    *  This funtion is used to change the compare1 value.  The compare output will
    *  reflect the new value on the next UDB clock.  The compare output will be
    *  driven high when the present counter value is less than or less than or
    *  equal to the compare register, depending on the mode.
    *
    * Parameters:
    *  compare:  New compare value.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void servo_WriteCompare1(uint16 compare) \
                                        
    {
        #if(servo_UsingFixedFunction)
            CY_SET_REG16(servo_COMPARE1_LSB_PTR, (uint16)compare);
        #else
            CY_SET_REG16(servo_COMPARE1_LSB_PTR, compare);
        #endif /* (servo_UsingFixedFunction) */
    }


    /*******************************************************************************
    * Function Name: servo_WriteCompare2
    ********************************************************************************
    *
    * Summary:
    *  This funtion is used to change the compare value, for compare1 output.
    *  The compare output will reflect the new value on the next UDB clock.
    *  The compare output will be driven high when the present counter value is
    *  less than or less than or equal to the compare register, depending on the
    *  mode.
    *
    * Parameters:
    *  compare:  New compare value.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void servo_WriteCompare2(uint16 compare) \
                                        
    {
        #if(servo_UsingFixedFunction)
            CY_SET_REG16(servo_COMPARE2_LSB_PTR, compare);
        #else
            CY_SET_REG16(servo_COMPARE2_LSB_PTR, compare);
        #endif /* (servo_UsingFixedFunction) */
    }
#endif /* UseOneCompareMode */

#if (servo_DeadBandUsed)


    /*******************************************************************************
    * Function Name: servo_WriteDeadTime
    ********************************************************************************
    *
    * Summary:
    *  This function writes the dead-band counts to the corresponding register
    *
    * Parameters:
    *  deadtime:  Number of counts for dead time
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void servo_WriteDeadTime(uint8 deadtime) 
    {
        /* If using the Dead Band 1-255 mode then just write the register */
        #if(!servo_DeadBand2_4)
            CY_SET_REG8(servo_DEADBAND_COUNT_PTR, deadtime);
        #else
            /* Otherwise the data has to be masked and offset */
            /* Clear existing data */
            servo_DEADBAND_COUNT &= ((uint8)(~servo_DEADBAND_COUNT_MASK));

            /* Set new dead time */
            #if(servo_DEADBAND_COUNT_SHIFT)
                servo_DEADBAND_COUNT |= ((uint8)((uint8)deadtime << servo_DEADBAND_COUNT_SHIFT)) &
                                                    servo_DEADBAND_COUNT_MASK;
            #else
                servo_DEADBAND_COUNT |= deadtime & servo_DEADBAND_COUNT_MASK;
            #endif /* (servo_DEADBAND_COUNT_SHIFT) */

        #endif /* (!servo_DeadBand2_4) */
    }


    /*******************************************************************************
    * Function Name: servo_ReadDeadTime
    ********************************************************************************
    *
    * Summary:
    *  This function reads the dead-band counts from the corresponding register
    *
    * Parameters:
    *  None
    *
    * Return:
    *  Dead Band Counts
    *
    *******************************************************************************/
    uint8 servo_ReadDeadTime(void) 
    {
        /* If using the Dead Band 1-255 mode then just read the register */
        #if(!servo_DeadBand2_4)
            return (CY_GET_REG8(servo_DEADBAND_COUNT_PTR));
        #else

            /* Otherwise the data has to be masked and offset */
            #if(servo_DEADBAND_COUNT_SHIFT)
                return ((uint8)(((uint8)(servo_DEADBAND_COUNT & servo_DEADBAND_COUNT_MASK)) >>
                                                                           servo_DEADBAND_COUNT_SHIFT));
            #else
                return (servo_DEADBAND_COUNT & servo_DEADBAND_COUNT_MASK);
            #endif /* (servo_DEADBAND_COUNT_SHIFT) */
        #endif /* (!servo_DeadBand2_4) */
    }
#endif /* DeadBandUsed */

#if (servo_UseStatus || servo_UsingFixedFunction)


    /*******************************************************************************
    * Function Name: servo_SetInterruptMode
    ********************************************************************************
    *
    * Summary:
    *  This function configures the interrupts mask control of theinterrupt
    *  source status register.
    *
    * Parameters:
    *  uint8 interruptMode: Bit field containing the interrupt sources enabled
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void servo_SetInterruptMode(uint8 interruptMode) 
    {
        CY_SET_REG8(servo_STATUS_MASK_PTR, interruptMode);
    }


    /*******************************************************************************
    * Function Name: servo_ReadStatusRegister
    ********************************************************************************
    *
    * Summary:
    *  This function returns the current state of the status register.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  uint8 : Current status register value. The status register bits are:
    *  [7:6] : Unused(0)
    *  [5]   : Kill event output
    *  [4]   : FIFO not empty
    *  [3]   : FIFO full
    *  [2]   : Terminal count
    *  [1]   : Compare output 2
    *  [0]   : Compare output 1
    *
    *******************************************************************************/
    uint8 servo_ReadStatusRegister(void) 
    {
        return (CY_GET_REG8(servo_STATUS_PTR));
    }

#endif /* (servo_UseStatus || servo_UsingFixedFunction) */


#if (servo_UseControl)


    /*******************************************************************************
    * Function Name: servo_ReadControlRegister
    ********************************************************************************
    *
    * Summary:
    *  Returns the current state of the control register. This API is available
    *  only if the control register is not removed.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  uint8 : Current control register value
    *
    *******************************************************************************/
    uint8 servo_ReadControlRegister(void) 
    {
        uint8 result;

        result = CY_GET_REG8(servo_CONTROL_PTR);
        return (result);
    }


    /*******************************************************************************
    * Function Name: servo_WriteControlRegister
    ********************************************************************************
    *
    * Summary:
    *  Sets the bit field of the control register. This API is available only if
    *  the control register is not removed.
    *
    * Parameters:
    *  uint8 control: Control register bit field, The status register bits are:
    *  [7]   : PWM Enable
    *  [6]   : Reset
    *  [5:3] : Compare Mode2
    *  [2:0] : Compare Mode2
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void servo_WriteControlRegister(uint8 control) 
    {
        CY_SET_REG8(servo_CONTROL_PTR, control);
    }

#endif /* (servo_UseControl) */


#if (!servo_UsingFixedFunction)


    /*******************************************************************************
    * Function Name: servo_ReadCapture
    ********************************************************************************
    *
    * Summary:
    *  Reads the capture value from the capture FIFO.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  uint8/uint16: The current capture value
    *
    *******************************************************************************/
    uint16 servo_ReadCapture(void) 
    {
        return (CY_GET_REG16(servo_CAPTURE_LSB_PTR));
    }

#endif /* (!servo_UsingFixedFunction) */


#if (servo_UseOneCompareMode)


    /*******************************************************************************
    * Function Name: servo_ReadCompare
    ********************************************************************************
    *
    * Summary:
    *  Reads the compare value for the compare output when the PWM Mode parameter is
    *  set to Dither mode, Center Aligned mode, or One Output mode.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  uint8/uint16: Current compare value
    *
    *******************************************************************************/
    uint16 servo_ReadCompare(void) 
    {
        #if(servo_UsingFixedFunction)
            return ((uint16)CY_GET_REG16(servo_COMPARE1_LSB_PTR));
        #else
            return (CY_GET_REG16(servo_COMPARE1_LSB_PTR));
        #endif /* (servo_UsingFixedFunction) */
    }

#else


    /*******************************************************************************
    * Function Name: servo_ReadCompare1
    ********************************************************************************
    *
    * Summary:
    *  Reads the compare value for the compare1 output.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  uint8/uint16: Current compare value.
    *
    *******************************************************************************/
    uint16 servo_ReadCompare1(void) 
    {
        return (CY_GET_REG16(servo_COMPARE1_LSB_PTR));
    }


    /*******************************************************************************
    * Function Name: servo_ReadCompare2
    ********************************************************************************
    *
    * Summary:
    *  Reads the compare value for the compare2 output.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  uint8/uint16: Current compare value.
    *
    *******************************************************************************/
    uint16 servo_ReadCompare2(void) 
    {
        return (CY_GET_REG16(servo_COMPARE2_LSB_PTR));
    }

#endif /* (servo_UseOneCompareMode) */


/*******************************************************************************
* Function Name: servo_ReadPeriod
********************************************************************************
*
* Summary:
*  Reads the period value used by the PWM hardware.
*
* Parameters:
*  None
*
* Return:
*  uint8/16: Period value
*
*******************************************************************************/
uint16 servo_ReadPeriod(void) 
{
    #if(servo_UsingFixedFunction)
        return ((uint16)CY_GET_REG16(servo_PERIOD_LSB_PTR));
    #else
        return (CY_GET_REG16(servo_PERIOD_LSB_PTR));
    #endif /* (servo_UsingFixedFunction) */
}

#if ( servo_KillModeMinTime)


    /*******************************************************************************
    * Function Name: servo_WriteKillTime
    ********************************************************************************
    *
    * Summary:
    *  Writes the kill time value used by the hardware when the Kill Mode
    *  is set to Minimum Time.
    *
    * Parameters:
    *  uint8: Minimum Time kill counts
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void servo_WriteKillTime(uint8 killtime) 
    {
        CY_SET_REG8(servo_KILLMODEMINTIME_PTR, killtime);
    }


    /*******************************************************************************
    * Function Name: servo_ReadKillTime
    ********************************************************************************
    *
    * Summary:
    *  Reads the kill time value used by the hardware when the Kill Mode is set
    *  to Minimum Time.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  uint8: The current Minimum Time kill counts
    *
    *******************************************************************************/
    uint8 servo_ReadKillTime(void) 
    {
        return (CY_GET_REG8(servo_KILLMODEMINTIME_PTR));
    }

#endif /* ( servo_KillModeMinTime) */

/* [] END OF FILE */
