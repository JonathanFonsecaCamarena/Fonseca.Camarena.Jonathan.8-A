/*******************************************************************************
* File Name: servo_PM.c
* Version 3.30
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "servo.h"

static servo_backupStruct servo_backup;


/*******************************************************************************
* Function Name: servo_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  servo_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void servo_SaveConfig(void) 
{

    #if(!servo_UsingFixedFunction)
        #if(!servo_PWMModeIsCenterAligned)
            servo_backup.PWMPeriod = servo_ReadPeriod();
        #endif /* (!servo_PWMModeIsCenterAligned) */
        servo_backup.PWMUdb = servo_ReadCounter();
        #if (servo_UseStatus)
            servo_backup.InterruptMaskValue = servo_STATUS_MASK;
        #endif /* (servo_UseStatus) */

        #if(servo_DeadBandMode == servo__B_PWM__DBM_256_CLOCKS || \
            servo_DeadBandMode == servo__B_PWM__DBM_2_4_CLOCKS)
            servo_backup.PWMdeadBandValue = servo_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(servo_KillModeMinTime)
             servo_backup.PWMKillCounterPeriod = servo_ReadKillTime();
        #endif /* (servo_KillModeMinTime) */

        #if(servo_UseControl)
            servo_backup.PWMControlRegister = servo_ReadControlRegister();
        #endif /* (servo_UseControl) */
    #endif  /* (!servo_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: servo_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  servo_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void servo_RestoreConfig(void) 
{
        #if(!servo_UsingFixedFunction)
            #if(!servo_PWMModeIsCenterAligned)
                servo_WritePeriod(servo_backup.PWMPeriod);
            #endif /* (!servo_PWMModeIsCenterAligned) */

            servo_WriteCounter(servo_backup.PWMUdb);

            #if (servo_UseStatus)
                servo_STATUS_MASK = servo_backup.InterruptMaskValue;
            #endif /* (servo_UseStatus) */

            #if(servo_DeadBandMode == servo__B_PWM__DBM_256_CLOCKS || \
                servo_DeadBandMode == servo__B_PWM__DBM_2_4_CLOCKS)
                servo_WriteDeadTime(servo_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(servo_KillModeMinTime)
                servo_WriteKillTime(servo_backup.PWMKillCounterPeriod);
            #endif /* (servo_KillModeMinTime) */

            #if(servo_UseControl)
                servo_WriteControlRegister(servo_backup.PWMControlRegister);
            #endif /* (servo_UseControl) */
        #endif  /* (!servo_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: servo_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  servo_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void servo_Sleep(void) 
{
    #if(servo_UseControl)
        if(servo_CTRL_ENABLE == (servo_CONTROL & servo_CTRL_ENABLE))
        {
            /*Component is enabled */
            servo_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            servo_backup.PWMEnableState = 0u;
        }
    #endif /* (servo_UseControl) */

    /* Stop component */
    servo_Stop();

    /* Save registers configuration */
    servo_SaveConfig();
}


/*******************************************************************************
* Function Name: servo_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  servo_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void servo_Wakeup(void) 
{
     /* Restore registers values */
    servo_RestoreConfig();

    if(servo_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        servo_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
