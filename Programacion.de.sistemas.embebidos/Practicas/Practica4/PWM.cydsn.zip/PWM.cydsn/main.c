/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
const int time = 200;
const int gradosPuntuales = 1300;
const int ceroGrados = 6000;

int main(void){   
    servo_Start();
    LCD_Start();
    Clock_1_Start();
    CyGlobalIntEnable;
    servo_WriteCompare(0);
    LCD_Position(0,4);
    LCD_PrintString("START :)");
    LCD_Position(1,5);
    LCD_PrintString("JONNY");
    CyDelay(time*10);
    int grados = 0;

    for (;;){
        if(grados<0)   grados = 0;
        if(grados>180) grados = 180;
        LCD_ClearDisplay();
        LCD_Position(0,4);
        LCD_PrintString("Degrees");
        LCD_Position(1,6);
        LCD_PrintNumber(grados);
        CyDelay(time);
        if (!Pin_2_Read()) grados +=10;
        if (!Pin_3_Read()) grados -=10;   
        if (!Pin_4_Read()){
            LCD_ClearDisplay();
            LCD_Position(0,1);
            LCD_PrintString("Ajustando :");
            LCD_PrintNumber(grados);
            CyDelay(time);
            servo_WriteCompare((grados/10)*gradosPuntuales+ceroGrados);         
            CyDelay(time*3);
        }
       //CyDelay(time);
    }   
 }