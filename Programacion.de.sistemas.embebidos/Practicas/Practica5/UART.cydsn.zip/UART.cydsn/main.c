/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h> 
#include <ctype.h>

#define STR_LEN 32
#define RX_BUF_LEN 128

#define SPACE ' '
#define TAB '\t'
#define CR  '\r'
#define LF  '\n'

const int speed = 2;
const double AGrados = 1.6;

char          str[STR_LEN+1] ; /* print buffer */
int           str_index = 0 ;
int           str_ready = 0 ;

void horario(int grados) {
    for (int x = 0; x<=grados * AGrados; x++){
        Pin_1_Write(0);
        Pin_2_Write(0);
        Pin_3_Write(0);
        Pin_4_Write(1);
        CyDelay(speed);
           
        Pin_1_Write(0);
        Pin_2_Write(0);
        Pin_3_Write(1);
        Pin_4_Write(0);
        CyDelay(speed);
           
        Pin_1_Write(0);
        Pin_2_Write(1);
        Pin_3_Write(0);
        Pin_4_Write(0);
        CyDelay(speed);
        
        Pin_1_Write(1);
        Pin_2_Write(0);
        Pin_3_Write(0);
        Pin_4_Write(0);
        CyDelay(speed);
    }
}

void antihorario(int grados){
     for (int x = grados * AGrados; x>=0; x--){
        Pin_1_Write(1);
        Pin_2_Write(0);
        Pin_3_Write(0);
        Pin_4_Write(0);
        CyDelay(speed);
         
        Pin_1_Write(0);
        Pin_2_Write(1);
        Pin_3_Write(0);
        Pin_4_Write(0);
        CyDelay(speed);
        
        Pin_1_Write(0);
        Pin_2_Write(0);
        Pin_3_Write(1);
        Pin_4_Write(0);
        CyDelay(speed);
        
        Pin_1_Write(0);
        Pin_2_Write(0);
        Pin_3_Write(0);
        Pin_4_Write(1);
        CyDelay(speed);
    }
 }     
    
inline int is_delimiter(uint8_t c){
    int result = 0 ;
    switch(c) {
    case CR:
    case LF:
    case TAB:
    case SPACE:
        result = c ;
        break ;
    }
    return( result ) ;
}

void cls(){
 UART_1_PutString("\033[2J\033[H");
}

void print(char *str){
    UART_1_PutString(str) ;
}

int check_str(void){
    int result = 0 ;
    uint8_t c ;
    while((result == 0) && (UART_1_GetRxBufferSize())) {
        c = UART_1_GetByte() ;
        result = is_delimiter(c) ;
        if (result) { /* a string delimter was detected */
            str[str_index] = 0 ;
            str_index = 0 ;
        } else { /* still in the middle of a string */
            str[str_index++] = c ;
            if (str_index >= STR_LEN) { /* string is too long */
                str[STR_LEN] = 0 ;
                str_index = 0 ;
                result = -1 ;
            }
        }      
    }
    return( result ) ;
}

int get_str(void){
    int result = 0 ;
    while(result == 0) {
        result = check_str() ;
    }
    return( result ) ;
}

int isNumber(const char * tmp){
    int isDigit = 0;
    unsigned int j=0;
    while(j<strlen(tmp) && isDigit == 0){
        isDigit = isdigit(tmp[j]);
        j++;
    }
    return isDigit;
}

int main (){
    CyGlobalIntEnable;
    UART_1_Start();
    //rxTor_StartEx(InterrupRX);
    int grados = 0;
    cls();
    for(;;){
        while (!check_str()) { 
            cls();
            print("\r\nJonathan Fonseca Camarena\r\n");
            print("*************************\r\n");
            print("\n\rIngrese La cantidad de Grados a girar: ");
            print(str); 
            CyDelay(50);
        }
        if(!isNumber(str)){
            print("\n\rESE NO ES UN NUMERO!!");
        } else { 
            sscanf(str, "%d", &grados);
            if(!(grados<=720) || !(grados>=-720)){
                print("\n\rFUERA DE RANGO (tardaria muchisimo!)");      
            } else {
            print("\n\rGIRANDO!!!!");
            if(grados <= 0){
                antihorario(-grados);
                grados = 0;
            } else {
                horario (grados);
            }
        }
      }
      CyDelay(1000);  
      *str = '\0';
      memset(&str[0], 0, sizeof(str));
      UART_1_ClearTxBuffer();
      UART_1_ClearRxBuffer();
    }
}
