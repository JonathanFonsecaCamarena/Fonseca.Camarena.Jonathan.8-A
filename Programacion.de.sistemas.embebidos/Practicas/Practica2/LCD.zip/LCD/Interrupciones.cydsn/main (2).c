/* ================================================================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ================================================================================
*/
#include "project.h"

const int VELOCIDAD = 70;

void enciendeLed(int x){
 switch (x){
    case 1:
            Pin_1_Write(1);      
        break;
        case 2:
            Pin_2_Write(1);
        break;
        case 3:
            Pin_3_Write(1);
        break;
        case 4:
        Pin_4_Write(1);
        break;
        case 5:
        Pin_5_Write(1);
        break;
        case 6:
        Pin_6_Write(1);
        break;
        case 7:
        Pin_7_Write(1);
        break;
        case 8:
        Pin_8_Write(1);
        break;
        case 9:
        Pin_9_Write(1);
        break;
        case 10:
        Pin_10_Write(1);
        break;
    }
}

void apagarLeds(){
    Pin_1_Write(0);
    Pin_2_Write(0);
    Pin_3_Write(0);
    Pin_4_Write(0);
    Pin_5_Write(0);
    Pin_6_Write(0);
    Pin_7_Write(0);
    Pin_8_Write(0);
    Pin_9_Write(0);
    Pin_10_Write(0);
}

void imprimeLCD(int x){
    LCD_Position(0,x);
    LCD_PutChar(LCD_CUSTOM_0);
    LCD_Position(1,x);
    LCD_PutChar(LCD_CUSTOM_0);
}

void limpiarLCD(){
    LCD_ClearDisplay();
}


int main(void){
    CyGlobalIntEnable; /* Enable global interrupts. */
    LCD_Start();
    apagarLeds();
    limpiarLCD(); 
    int sw1 = 0;
    int sw2 = 0;
    int cont = 0;
    for(;;cont++){
        if(Pin_12_Read() == 0 && Pin_13_Read() == 0){
            apagarLeds();
            limpiarLCD();
            Pin_11_Write(1);
        }
        if(Pin_12_Read() == 1 && Pin_13_Read() == 0){
            enciendeLed(cont);
            imprimeLCD(cont-1);
            if(cont>16){
                cont=0;   
                apagarLeds();
                limpiarLCD();   
            }
            Pin_11_Write(1);
        }
         if(Pin_12_Read() == 0 && Pin_13_Read() == 1){
            Pin_11_Write(0);
            limpiarLCD();
            apagarLeds();
            LCD_PrintString("Se hizo la luz");
        }
        if(Pin_12_Read() == 1 && Pin_13_Read()== 1){
            Pin_11_Write(0);
            apagarLeds();
            limpiarLCD();
            LCD_PrintString("Se hizo la luz");
        }
        CyDelay(VELOCIDAD);
    }
}
/* [] END OF FILE */
