/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>

uint16 flag = 0;
uint8 myVar;

CY_ISR(encoder_interrupt_handler) {
    flag = 1;
    myVar = Pin_1_ClearInterrupt();
}

int main(void)
{
    
    uint16 count = 0;
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    
    isr_1_StartEx(encoder_interrupt_handler); 
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    UART_Start();
    UART_PutString("COM Port Open");
    
    for(;;)
    {
        CyDelay(500);
        
        char buf[6];
        sprintf(buf,"%hu",flag);
        UART_PutString(buf);

        /* Place your application code here. */
        if (flag == 1)
        {
            flag = 0; /* reset flag  */
            
            count++;
            
            char buf[6];
            sprintf(buf,"%hu",count);
            UART_PutString(buf);
        }
    }
}

/* [] END OF FILE */
